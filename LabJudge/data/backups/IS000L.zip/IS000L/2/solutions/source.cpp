#include<iostream>
int main() {
cout::"Hello World"
return 0;
}